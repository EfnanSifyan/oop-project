public enum ShoeType {

    Sports{
        @Override
        public String toString() {
            return "Sports";
        }
    },
    Sneaker{
        @Override
        public String toString() {
            return "Sneaker";
        }
    },
    Boots{
        @Override
        public String toString() {
            return "Boots";
        }
    }

}
