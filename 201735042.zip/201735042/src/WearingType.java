public enum WearingType {
    Tshirt{
        @Override
        public String toString() {
            return "T-Shirt";
        }
    },
    Pants{
        @Override
        public String toString() {
            return "Pants";
        }
    },
    Underwear{
        @Override
        public String toString() {
            return "Underwear";
        }
    },
    Sweater{
        @Override
        public String toString() {
            return "Sweater";
        }
    },
    Jacket{
        @Override
        public String toString() {
            return "Jacket";
        }
    }
}