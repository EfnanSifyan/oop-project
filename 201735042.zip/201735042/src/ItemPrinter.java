public interface ItemPrinter {

    // Interface for lambda - INTERFACE IS USED
    void printItem(Item item);
}
